jQuery(function ($) {

	'use strict';

	
});